defmodule EdgeApi.OddsCache do
  @moduledoc """
  ETS-backed GenServer for sub-millisecond odds lookups.
  
  Stores the latest odds from all sources (Polymarket, sportsbooks)
  in an ETS table for blazing fast reads. Writes come from the
  scraper ingestion pipeline.
  
  Data structure per game:
  %{
    game_id: "nba-lal-hou-2026-04-18",
    sport: "nba",
    home: "LAL",
    away: "HOU",
    sources: %{
      "polymarket" => %{home: 0.34, away: 0.67, updated_at: ~U[...]},
      "draftkings" => %{home: 0.40, away: 0.60, updated_at: ~U[...]},
      "fanduel"    => %{home: 0.38, away: 0.62, updated_at: ~U[...]}
    },
    edge: %{
      side: "home",
      polymarket_price: 0.34,
      fair_value: 0.40,
      edge_cents: 6,
      confidence: :medium
    }
  }
  """
  use GenServer

  @table :odds_cache
  @edge_threshold 5  # Minimum edge in cents to alert

  # ── Client API ──────────────────────────────────────────

  def start_link(_opts) do
    GenServer.start_link(__MODULE__, %{}, name: __MODULE__)
  end

  @doc "Get all current odds for a specific game"
  def get_game(game_id) do
    case :ets.lookup(@table, game_id) do
      [{^game_id, data}] -> {:ok, data}
      [] -> {:error, :not_found}
    end
  end

  @doc "Get all games with active edges above threshold"
  def get_edges(min_edge \\ @edge_threshold) do
    :ets.foldl(
      fn {_key, game}, acc ->
        case game do
          %{edge: %{edge_cents: edge}} when edge >= min_edge ->
            [game | acc]
          _ ->
            acc
        end
      end,
      [],
      @table
    )
    |> Enum.sort_by(& &1.edge.edge_cents, :desc)
  end

  @doc "Get all games for a sport"
  def get_by_sport(sport) do
    :ets.foldl(
      fn {_key, game}, acc ->
        if game.sport == sport, do: [game | acc], else: acc
      end,
      [],
      @table
    )
  end

  @doc "Ingest new odds from a scraper source"
  def ingest_odds(game_id, source, odds_data) do
    GenServer.cast(__MODULE__, {:ingest, game_id, source, odds_data})
  end

  # ── Server Callbacks ────────────────────────────────────

  @impl true
  def init(_state) do
    table = :ets.new(@table, [:named_table, :set, :public, read_concurrency: true])
    {:ok, %{table: table, game_count: 0}}
  end

  @impl true
  def handle_cast({:ingest, game_id, source, odds_data}, state) do
    game = case :ets.lookup(@table, game_id) do
      [{^game_id, existing}] -> existing
      [] -> %{
        game_id: game_id,
        sport: odds_data[:sport] || "unknown",
        home: odds_data[:home],
        away: odds_data[:away],
        sources: %{},
        edge: nil
      }
    end

    # Update the source's odds
    updated_sources = Map.put(game.sources, source, %{
      home: odds_data[:home_odds],
      away: odds_data[:away_odds],
      updated_at: DateTime.utc_now()
    })

    updated_game = %{game | sources: updated_sources}

    # Recalculate edge
    updated_game = calculate_edge(updated_game)

    # Store in ETS
    :ets.insert(@table, {game_id, updated_game})

    # If edge exceeds threshold, broadcast to WebSocket subscribers
    if updated_game.edge && updated_game.edge.edge_cents >= @edge_threshold do
      Phoenix.PubSub.broadcast(
        EdgeApi.PubSub,
        "edges:all",
        {:new_edge, updated_game}
      )

      Phoenix.PubSub.broadcast(
        EdgeApi.PubSub,
        "edges:#{updated_game.sport}",
        {:new_edge, updated_game}
      )
    end

    {:noreply, state}
  end

  # ── Edge Calculation ────────────────────────────────────

  defp calculate_edge(%{sources: sources} = game) when map_size(sources) < 2 do
    %{game | edge: nil}
  end

  defp calculate_edge(%{sources: sources} = game) do
    polymarket = Map.get(sources, "polymarket")

    # Get the average of all non-Polymarket sources as "fair value"
    sportsbook_odds = sources
      |> Map.drop(["polymarket"])
      |> Map.values()
      |> Enum.map(& &1.home)

    if polymarket && length(sportsbook_odds) > 0 do
      fair_home = Enum.sum(sportsbook_odds) / length(sportsbook_odds)
      fair_away = 1.0 - fair_home

      # Check if Polymarket underprices either side
      home_edge = round((fair_home - polymarket.home) * 100)
      away_edge = round((fair_away - polymarket.away) * 100)

      edge = cond do
        home_edge >= @edge_threshold ->
          %{
            side: "home",
            team: game.home,
            polymarket_price: polymarket.home,
            fair_value: Float.round(fair_home, 3),
            edge_cents: home_edge,
            confidence: edge_confidence(home_edge)
          }
        away_edge >= @edge_threshold ->
          %{
            side: "away",
            team: game.away,
            polymarket_price: polymarket.away,
            fair_value: Float.round(fair_away, 3),
            edge_cents: away_edge,
            confidence: edge_confidence(away_edge)
          }
        true ->
          nil
      end

      %{game | edge: edge}
    else
      %{game | edge: nil}
    end
  end

  defp edge_confidence(edge) when edge >= 10, do: :high
  defp edge_confidence(edge) when edge >= 7, do: :medium
  defp edge_confidence(_edge), do: :low
end
