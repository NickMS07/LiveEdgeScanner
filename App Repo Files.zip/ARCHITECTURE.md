# Live Edge Scanner — System Architecture

## Overview

A real-time sports odds edge-finding platform that scrapes Polymarket and sportsbook odds, 
compares them in real-time, and surfaces mispriced bets to users.

## Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Scraping | Playwright (Node.js) | Headless browser scraping of Polymarket, sportsbooks |
| Real-time API | Elixir + Phoenix | WebSocket channels, real-time data broadcast |
| Database | PostgreSQL | Persistent odds history, user portfolios |
| Cache | Redis | Hot odds cache, rate limiting |
| Frontend | React (Next.js) | Dashboard UI, deployed on Vercel |
| Hosting | Fly.io (Elixir) + Railway (Playwright workers) | Infrastructure |

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────┐
│                    FRONTEND (Vercel)                      │
│              React / Next.js Dashboard                   │
│         WebSocket connection to Phoenix API               │
└───────────────────────┬─────────────────────────────────┘
                        │ wss://
                        ▼
┌─────────────────────────────────────────────────────────┐
│              PHOENIX API SERVER (Fly.io)                  │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  WebSocket   │  │   REST API   │  │  Edge Calc   │  │
│  │  Channels    │  │  /api/odds   │  │   Engine     │  │
│  │              │  │  /api/edges  │  │              │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │
│         │                 │                  │          │
│  ┌──────▼─────────────────▼──────────────────▼───────┐  │
│  │              GenServer / ETS Cache                  │  │
│  │         (Hot odds data, sub-second access)          │  │
│  └──────────────────────┬────────────────────────────┘  │
│                         │                               │
└─────────────────────────┼───────────────────────────────┘
                          │
              ┌───────────▼───────────┐
              │    PostgreSQL + Redis  │
              │    (Persistent store)  │
              └───────────┬───────────┘
                          │
┌─────────────────────────┼───────────────────────────────┐
│           SCRAPER WORKERS (Railway / Fly.io)             │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Polymarket  │  │  Sportsbook  │  │   UFC Odds   │  │
│  │   Scraper    │  │   Scraper    │  │   Scraper    │  │
│  │ (Playwright) │  │ (Playwright) │  │ (Playwright) │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│                                                          │
│  Headless Chromium → Parse odds → POST to Phoenix API    │
└─────────────────────────────────────────────────────────┘
```

## Data Flow

1. **Scraper workers** run on a schedule (every 30-60 seconds)
2. Playwright opens Polymarket + sportsbook pages in headless Chrome
3. Parsed odds are POSTed to the Phoenix API via authenticated endpoint
4. Phoenix stores in PostgreSQL, caches in ETS/Redis
5. **Edge Calculation Engine** compares odds across sources
6. When edge > threshold (e.g., 5¢), Phoenix broadcasts via WebSocket
7. **Frontend** receives real-time alert, displays to user

## Key Design Decisions

- **Why Playwright over simple HTTP?** Polymarket renders odds client-side via JavaScript. 
  Simple HTTP requests won't see the data. Playwright runs a real browser.
- **Why Elixir/Phoenix?** Built for real-time. Phoenix Channels handle thousands of 
  concurrent WebSocket connections. GenServers manage scraper state. OTP supervision 
  trees auto-restart crashed scrapers.
- **Why separate scraper workers?** Playwright is memory-heavy. Isolating scrapers 
  lets the Phoenix API stay lightweight and fast.
