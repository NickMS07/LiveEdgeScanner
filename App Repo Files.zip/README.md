# 🔍 Live Edge Scanner

Real-time sports odds edge finder. Scrapes Polymarket and sportsbook odds, 
compares them instantly, and alerts you when a bet is mispriced.

## How It Works

1. **Playwright scrapers** run every 60 seconds, pulling live odds from Polymarket and sportsbooks
2. **Elixir/Phoenix API** receives odds, stores them, and calculates edges in real-time
3. **WebSocket channels** broadcast edge alerts to all connected clients instantly
4. **React frontend** displays edges with confidence ratings and one-click action

## Architecture

```
Scrapers (Playwright) → Phoenix API (Elixir) → WebSocket → React Frontend
                              ↕
                     PostgreSQL + Redis
```

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 20+
- Elixir 1.17+ (for local dev without Docker)

### Run with Docker (recommended)
```bash
git clone https://github.com/yourusername/live-edge-scanner.git
cd live-edge-scanner
docker-compose up
```

This starts:
- PostgreSQL on port 5432
- Redis on port 6379  
- Phoenix API on port 4000
- Playwright scraper (runs every 60s)

### Run locally (development)

**1. Start the Phoenix API:**
```bash
cd edge_api
mix deps.get
mix ecto.create
mix ecto.migrate
mix phx.server
```

**2. Start the scraper:**
```bash
cd scrapers
npm install
npx playwright install chromium
node polymarket.js
```

**3. Start the frontend:**
```bash
cd frontend
npm install
npm run dev
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/odds/ingest` | Scrapers push odds here |
| GET | `/api/odds/:game_id` | Get odds for a specific game |
| GET | `/api/edges` | Get all current edges |
| GET | `/api/edges/:sport` | Get edges filtered by sport |

## WebSocket Channels

Connect to `wss://your-api.fly.dev/socket` and join:
- `edges:all` — All sports
- `edges:nba` — NBA only
- `edges:ufc` — UFC only
- `edges:mlb` — MLB only
- `edges:nhl` — NHL only

## Environment Variables

### Phoenix API
| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | — |
| `REDIS_URL` | Redis connection string | `redis://localhost:6379` |
| `SCRAPER_API_KEY` | Auth key for scraper ingestion | `dev-key-change-me` |
| `SECRET_KEY_BASE` | Phoenix secret key | — |
| `PORT` | HTTP port | `4000` |

### Scrapers
| Variable | Description | Default |
|----------|-------------|---------|
| `EDGE_API_URL` | Phoenix API base URL | `http://localhost:4000` |
| `SCRAPER_API_KEY` | Must match API's key | `dev-key-change-me` |
| `SCRAPE_INTERVAL` | Milliseconds between scrapes | `60000` |

## Deployment

### Phoenix API → Fly.io
```bash
cd edge_api
fly launch
fly deploy
```

### Scrapers → Railway
```bash
cd scrapers
railway init
railway up
```

### Frontend → Vercel
```bash
cd frontend
vercel deploy
```

## Project Structure
```
live-edge-scanner/
├── edge_api/                # Elixir/Phoenix real-time API
│   ├── lib/
│   │   ├── edge_api/
│   │   │   ├── application.ex      # OTP supervision tree
│   │   │   ├── odds_cache.ex       # ETS-backed real-time cache
│   │   │   └── edge_calculator.ex  # Edge detection engine
│   │   └── edge_api_web/
│   │       ├── channels/
│   │       │   └── edges_channel.ex  # WebSocket broadcasting
│   │       ├── controllers/
│   │       │   └── odds_controller.ex  # REST API
│   │       └── router.ex
│   ├── mix.exs
│   └── Dockerfile
├── scrapers/                # Playwright scraping workers
│   ├── polymarket.js        # Polymarket odds scraper
│   ├── sportsbooks.js       # DraftKings/FanDuel scraper
│   ├── package.json
│   └── Dockerfile
├── frontend/                # React/Next.js dashboard
│   └── (deployed on Vercel)
├── docker-compose.yml       # Full stack local dev
├── ARCHITECTURE.md          # System design document
└── README.md                # This file
```

## License

MIT
